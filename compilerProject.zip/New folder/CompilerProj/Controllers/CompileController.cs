﻿using CompilerProj.Models;
using CompilerProj.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server;
using System.IO;


namespace CompilerProj.Controllers
{
    public class CompileController : Controller
    {
        

        public IActionResult Index()
        {
            Code code = new Code();

            code.code = " kfkfjkl";

            Scannercs scannercs = new Scannercs();

            //scannercs.Scan(code,20);

            //Code.codes[0] = Code.Code;

            CodeScanner codescanner = new CodeScanner() { 

                Code = code,
                Scanner=scannercs,

            };

            return View(codescanner);
        }

        [HttpPost]
        public IActionResult Index(CodeScanner model)
        {
            String[] output = new string[model.Code.code.Length];
            string temp = "";
            for (var i = 0; i < model.Code.code.Length; i++)
            {
                if (model.Code.code[i] == '\n')
                {
                    if (temp != "")
                    {
                        output[i] = temp;
                        temp = "";
                    }
                    continue;
                }
                temp += model.Code.code[i];



            }
            if (temp != "")
            {
                output[model.Code.code.Length - 1] = temp;
                temp = "";
            }

            model.Scanner.Scan(output, output.Length);


            //model.Scanner = Scan(output, output.Length,scannercs);
           




            return View(model);
        }

        public IActionResult Show()
        {
            Code code = new Code();

            code.code = " kfkfjkl";

            Scannercs scannercs = new Scannercs();

            //scannercs.Scan(code,20);

            //Code.codes[0] = Code.Code;

            CodeScanner codescanner = new CodeScanner()
            {

                Code = code,
                Scanner = scannercs,

            };

            return View(codescanner);
        }

       

        /*[HttpPost]
        public IActionResult Index(Code model)
        {

            //FileStream stream ;

            //if (ModelState.IsValid)
            //{
              
            //    string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Files");

            //    //create folder if not exist
            //    if (!Directory.Exists(path))
            //        Directory.CreateDirectory(path);

            //    //get file extension
            //    FileInfo fileInfo = new FileInfo(model.File.FileName);
            //    string fileName = model.FileName + fileInfo.Extension;

            //    string fileNameWithPath = Path.Combine(path, fileName);

                
            

            //using (stream = new FileStream(fileNameWithPath, FileMode.Create))
            //    {
            //        model.File.CopyTo(stream);
            //        var file= File.OpenRead(fileNameWithPath);
            //        return file.ToString();

            //    }
                
            //}
            //return ""; 

            return View(model);


        }*/







        /*private void WriteData()
         {
             if (File.Exists(Server.MapPath("App_Data/U3.txt")))
             {
                 TextBox1.Text = File.ReadAllText(Server.MapPath("App_Data/U3.txt"));
             }
             File.WriteAllText(Server.MapPath("App_Data/U3.txt"), TextBox1.Text);
         }*/





    }
}
