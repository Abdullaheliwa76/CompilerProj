﻿using CompilerProj.Models;

namespace CompilerProj.ViewModels
{
    public class CodeScanner
    {
        public Code Code { get; set; }
        public Scannercs? Scanner { get; set; }

    }
}
