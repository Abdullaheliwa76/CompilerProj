﻿namespace CompilerProj.Models
{
    public class Code
    {
        public String? code { get; set; }
        
    }
}
