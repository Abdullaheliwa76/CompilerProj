﻿namespace CompilerProj.Models
{
    public class CodeSplitercs
    {
        public static String[] codeLine = new String[100];
        
        public static void splitCode()
        {
            for (int i =0; i<100; i++)
            {

                codeLine[i] = "";

            }
            
          //  int x = 0;

        //    foreach (char c in Code.code)
        //    {
        //        if(c == '\n') { x++;continue; }

        //        codeLine[x] += c;

        //    }
        }
    }
}
